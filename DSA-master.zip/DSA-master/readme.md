## Best-Books-for-Learning-Data-Structures-and-Algorithms

> As Seen From this [Youtube Videos](https://www.youtube.com/watch?v=FWmuxvOgh6Q)

👨‍💻 Data Structures & Algorithms

Computer Science Distilled - https://amzn.to/39jYZ0S​

Grokking Algorithms - https://amzn.to/2JcBrjS​

Introduction to Algorithms - https://amzn.to/2V03JRb​

Elements of Programming Interviews (Python) - https://amzn.to/35XPQJw​

Elements of Programming Interviews (Java) - https://amzn.to/374W5KT​


⚙ Software Engineering & Architecture

Clean Code - https://amzn.to/3nHNtAC​

Clean Architecture - https://amzn.to/3kZ7UqR​

Refactoring - https://amzn.to/377VXdM​

The Productive Programmer - https://amzn.to/33aMeSE​

Pragmatic Thinking & Learning - https://amzn.to/2J5IfzM​


 🌩 Distributed Systems

Web Scalability for Startup Engineers - https://amzn.to/39c55QV​

Designing Data Intensive Applications - https://amzn.to/3fxgOLm​

Understanding Distributed Systems - https://amzn.to/3cjChr5​

Software Engineering at Google - https://amzn.to/3rfJc8L​

Building Microservices - https://amzn.to/2UUPsFi​


📕 OTHER RECOMMENDATIONS

Algorithm Design Manual - https://amzn.to/35ZXx1D​

Algorithms (4th Ed.) - https://amzn.to/3m9c1kN​
